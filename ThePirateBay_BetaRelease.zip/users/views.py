from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from users import models, forms
from django.core.exceptions import ObjectDoesNotExist
'''from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required'''


# Create your views here.

def register(request):
	registration_form = forms.Registration(request.POST or None)

	reg_context = {
		'reg_form': registration_form,
	}

	if registration_form.is_valid():
		registration_obj = models.User()
		registration_obj.name = registration_form.cleaned_data['name']
		registration_obj.user_name = registration_form.cleaned_data['user_name']
		registration_obj.zipcode = registration_form.cleaned_data['zipcode']
		registration_obj.email = registration_form.cleaned_data['email']
		registration_obj.address = registration_form.cleaned_data['address']
		registration_obj.password = registration_form.cleaned_data['password']
		registration_obj.confirm_password = registration_form.cleaned_data['confirm_password']
		registration_obj.tool_pickup_preference = registration_form.cleaned_data['tool_pickup_preference']
		# registration_obj.tool_location = registration_form.cleaned_data['tool_location']


		registration_obj.save()


		# Following line sends user to profile after registration
		return HttpResponseRedirect('/')

	return render(request, 'register.html', reg_context)


def login(request):
	login_form = forms.Login(request.POST or None)
	Login_context = {
		'login_form': login_form,
	}

	if login_form.is_valid():

		login_obj = models.User.objects.filter(user_name=login_form.cleaned_data['user_name'],
											   password=login_form.cleaned_data['password'])

		if not login_obj:
			Login_context['error'] = 'Invalid Credentials.'
		else:
			request.session['open'] = True
			request.session['user_name'] = login_form.cleaned_data['user_name']

			user_zip = models.User.objects.get(user_name=request.session['user_name']).zipcode
			try:
				shed_zip = models.Shed.objects.get(shed_zip=user_zip)
			except ObjectDoesNotExist:
				return HttpResponseRedirect('/shed')



			return HttpResponseRedirect('/up')

	return render(request, 'login.html', Login_context)

#@login_required
def user_profile(request):
	user_zip = models.User.objects.get(user_name=request.session['user_name']).zipcode
	try:
		shed_zip = models.Shed.objects.get(shed_zip=user_zip)
	except ObjectDoesNotExist:
		return HttpResponseRedirect('/shed')
	user = models.User.objects.get(user_name=request.session['user_name'])
	name = user.name
	email = user.email
	zipcode = user.zipcode
	address = user.address
	tool_pickup_preference = user.tool_pickup_preference
	# tool_location = user.tool_location
	Profile_context = {
		'name': name,
		'email': email,
		'zipcode': zipcode,
		'address': address,
		'tool_pickup_preference':tool_pickup_preference
		# 'tool_location':tool_location
	}
	return render(request, 'profile.html', Profile_context)

#@login_required
def edit_profile(request):
	user_zip = models.User.objects.get(user_name=request.session['user_name']).zipcode
	try:
		shed_zip = models.Shed.objects.get(shed_zip=user_zip)
	except ObjectDoesNotExist:
		return HttpResponseRedirect('/shed')
	user_change_form = forms.EditUser(request.POST or None)

	user_change_context = {
		'form': user_change_form,
	}
	user = models.User.objects.get(user_name=request.session['user_name'])

	if user_change_form.is_valid():
		
		if user_change_form.cleaned_data['name']:
			user.name = user_change_form.cleaned_data['name']
			user.save()
			HttpResponseRedirect('/up')

		if user_change_form.cleaned_data['tool_pickup_preference']:
			user.tool_pickup_preference = user_change_form.cleaned_data['tool_pickup_preference']
			user.save()
			HttpResponseRedirect('/up')

		if user_change_form.cleaned_data['address']:
			user.address = user_change_form.cleaned_data['address']
			user.save()
			HttpResponseRedirect('/up')

		if user_change_form.cleaned_data['zipcode']:
			user.zipcode = user_change_form.cleaned_data['zipcode']
			user.save()
			HttpResponseRedirect('/up')

		if user_change_form.cleaned_data['email']:
			user.email = user_change_form.cleaned_data['email']
			user.save()
			HttpResponseRedirect('/up')

		# if user_change_form.cleaned_data['tool_location']:
			# user.email = user_change_form.cleaned_data['tool_location']
			# user.save()
			# HttpResponseRedirect('/up')
	
	user_change_context['name'] = models.User.objects.get(user_name=user).name
	user_change_context['zipcode'] = models.User.objects.get(user_name=user).zipcode
	user_change_context['tool_pickup_preference'] = models.User.objects.get(user_name=user).tool_pickup_preference
	user_change_context['address'] = models.User.objects.get(user_name=user).address
	user_change_context['email'] = models.User.objects.get(user_name=user).email
	# user_change_context['tool_location'] = models.User.objects.get(user_name=user).tool_location
	
	return render(request, 'edit_profile.html', user_change_context)

#@login_required
def logout(request):
	request.session['open'] = False
	return HttpResponseRedirect('/')

	return render(request, 'login.html', Login_context)


#@login_required
def tools(request):
	user_zip = models.User.objects.get(user_name=request.session['user_name']).zipcode
	try:
		shed_zip = models.Shed.objects.get(shed_zip=user_zip)
	except ObjectDoesNotExist:
		return HttpResponseRedirect('/shed')
	tools_form = forms.Tools(request.POST or None)

	tools_context = {
		'tools_form': tools_form,
	}

	if tools_form.is_valid():
		tools_obj = models.Tools()
		user_tool = models.User.objects.get(user_name=request.session['user_name'])
		tools_obj.tool_name = tools_form.cleaned_data['tool_name']
		tools_obj.tool_description = tools_form.cleaned_data['tool_description']
		tools_obj.tool_category = tools_form.cleaned_data['tool_category']
		toolpref = tools_form.cleaned_data['tool_pickup_preference']
		tools_obj.tool_pickup_preference = toolpref
		if toolpref == "Home":
			tools_obj.tool_location = user_tool.address
		elif toolpref == "Shed":
			sheds = models.Shed.objects.all().filter(shed_zip=user_tool.zipcode)
			for shed in sheds:
				sh_address = shed.shed_address
			tools_obj.tool_location = sh_address
		# else:
			# tools_obj.tool_location = tools_form.cleaned_data['tool_location']
		#for tool user
		tools_obj.tool_owner = user_tool
		tools_obj.tool_zip = user_tool.zipcode
		tools_obj.save()
		# Following line sends user to profile after registration
		return HttpResponseRedirect('/up')

	return render(request, 'add_tool.html', tools_context)

#@login_required
def listtools(request):
	user_zip = models.User.objects.get(user_name=request.session['user_name']).zipcode
	try:
		shed_zip = models.Shed.objects.get(shed_zip=user_zip)
	except ObjectDoesNotExist:
		return HttpResponseRedirect('/shed')

	user_tool = models.User.objects.get(user_name=request.session['user_name'])
	tools = models.Tools.objects.all().filter(tool_owner=user_tool)

	the_tool_list = []
	for tool in tools:
		inner_list = [
					  str(tool.id),
					  tool.tool_name,
					  tool.tool_description,
					  tool.tool_category,
					  tool.tool_pickup_preference,
					  tool.tool_location,
					  tool.tool_owner,

					 ]
		the_tool_list.append(inner_list)

	context = {
		'tool_list': the_tool_list
	}

	return render(request, 'list_tools.html', context)

#@login_required
def toolsinzip(request):
	user_zip = models.User.objects.get(user_name=request.session['user_name']).zipcode
	try:
		shed_zip = models.Shed.objects.get(shed_zip=user_zip)
	except ObjectDoesNotExist:
		return HttpResponseRedirect('/shed')

	user_tool = models.User.objects.get(user_name=request.session['user_name'])
	user_zip = models.User.objects.get(user_name=user_tool).zipcode
	#editing the next line, to prevent user seeing his own tool
	user_name = request.session['user_name']
	tools = models.Tools.objects.all().filter(tool_zip=user_zip).exclude(tool_owner=user_name)

	the_tool_list = []
	for tool in tools:
		inner_list = [
					  str(tool.id),
					  tool.tool_name,
					  tool.tool_description,
					  tool.tool_category,
					  tool.tool_pickup_preference,
					  tool.tool_location,
					  tool.tool_owner,

					 ]
		the_tool_list.append(inner_list)

	context = {
		'tool_list': the_tool_list
	}

	return render(request, 'tools_in_zip.html', context)

#@login_required
def shed_creation(request):
	shed_form = forms.Shed_Creation(request.POST or None)

	shed_context = {
		'shed_form': shed_form,
	}

	if shed_form.is_valid():
		shed_obj = models.Shed()
		shed_obj.shed_name = shed_form.cleaned_data['shed_name']
		shed_obj.shed_address = shed_form.cleaned_data['shed_address']
		#Get current user.
		admin = models.User.objects.get(user_name=request.session['user_name'])
		shed_obj.shed_admin=admin.user_name
		shed_obj.shed_zip=admin.zipcode
		shed_obj.save()


		# Following line sends user to profile after registration
		return HttpResponseRedirect('/up')

	return render(request, 'shed.html', shed_context)

'''#@login_required
def request_share(request):
	share_form = forms.StartShare(request.POST or None)
	share_context = {
		'share_form': share_form,
	}
	if request.method=='GET' and 'tid' in request.GET:
		share_context['tool_id'] = request.GET['tid']
	elif request.method=='POST':
		if share_form.is_valid():
			share_obj = models.ShareTool()
			tool = share_form.cleaned_data['tool']
			share_obj.share_tool = tool
			share_obj.share_init = models.User.objects.get(user_name=request.session['user_name'])
			share_obj.share_exec = models.Tools.objects.get(id=tool).tool_owner
			share_obj.share_days = share_form.cleaned_data['days']
			# share_obj.share_startdate = share_form.cleaned_data['startdate']
			# share_obj.share_enddate = share_form.cleaned_data['enddate']
			share_obj.save()
			return HttpResponseRedirect('/up')

	return render(request, 'startshare.html', share_context)
'''
def request_share(request,tid):
	user_zip = models.User.objects.get(user_name=request.session['user_name']).zipcode
	try:
		shed_zip = models.Shed.objects.get(shed_zip=user_zip)
	except ObjectDoesNotExist:
		return HttpResponseRedirect('/shed')
	borrow_user = models.User.objects.get(user_name=request.session['user_name'])
	borrow_tool = models.Tools.objects.get(id=tid)

	location = borrow_tool.tool_location
	owner = borrow_tool.tool_owner

	
	if borrow_tool.tool_available =='True':
		message = "Tool is your's now"
		borrow_tool.tool_available='False'
		
	else:
		message = "Sorry, Tool is already taken"
	share_context= {'location': location,
	'owner': owner,
	'message':message,}	
	return render(request, 'startshare.html', share_context)






'''
#Error Being thrown , better to keep it in R2.
def display_shed(request):
	user = models.User.objects.get(user_name=request.session['user_name'])
	zip = user.zipcode
	try:
		shed= models.Shed.objects.filter(shed_zip=zip)
	except ObjectDoesNotExist:
		HttpResponseRedirect('/up')
	#shed_name=shed.shed_name
	shed_admin=shed.shed_admin
	shed_address=shed.shed_address
	shed_zip=shed.shed_zip

	shed_info_context ={
		#'shed_name':shed_name,
		'shed_address':shed_address,
		'shed_zip':shed_zip,
		'shed_admin':shed_admin,
	}
	return render(request, 'display_shed.html',shed_info_context)
'''
