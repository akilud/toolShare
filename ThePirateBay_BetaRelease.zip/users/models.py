from django.db import models

# Create your models here.

class User(models.Model):
	prefs = (
		("Home", "Home"),
		("Shed", "Shed"),
		)
	user_name = models.CharField(max_length=40, primary_key=True)
	name = models.CharField(max_length=20)
	email = models.EmailField()
	password = models.CharField(max_length=20)
	confirm_password = models.CharField(max_length=20)
	zipcode = models.IntegerField()
	address = models.CharField(max_length=60)
	tool_pickup_preference	= models.CharField(max_length=20, choices=prefs)
	tool_location	= models.CharField(max_length=60)


	def __str__(self):
		return self.user_name

class Tools(models.Model):
	tool_name = models.CharField(max_length=20)
	tool_description = models.CharField(max_length=60)
	tool_category = models.CharField(max_length=30)
	tool_pickup_preference = models.CharField(max_length=20)
	tool_location = models.CharField(max_length=30)
	tool_owner = models.CharField(max_length=20)
	tool_zip = models.IntegerField()
	tool_available = models.BooleanField(default=True) #Field to show if tool is being shared right now
	
	def __str__(self):
		return self.tool_name

class Shed(models.Model):
	shed_name = models.CharField(max_length=30)
	shed_address = models.CharField(max_length=60)
	shed_zip = models.IntegerField(primary_key=True)
	shed_admin = models.CharField(max_length=20)

	def __str__(self):
		return self.shed_name
		
'''class ShareTool(models.Model):
	share_init = models.CharField(max_length=20)
	share_exec = models.CharField(max_length=20)
	share_tool = models.IntegerField()
	share_approval = models.NullBooleanField()
	share_days = models.IntegerField()
	# share_startdate = models.DateField(blank=False, null=False)
	# share_enddate = models.DateField(blank=False, null=False)

	def __str__(self):
		return self.share_init

'''
